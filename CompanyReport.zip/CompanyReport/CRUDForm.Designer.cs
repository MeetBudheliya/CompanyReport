﻿
namespace CompanyReport
{
    partial class CRUDForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.add_name_txt = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.update_id_txt = new System.Windows.Forms.TextBox();
            this.update_name_txt = new System.Windows.Forms.TextBox();
            this.delete_id_txt = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.add = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // add_name_txt
            // 
            this.add_name_txt.Location = new System.Drawing.Point(398, 64);
            this.add_name_txt.Name = "add_name_txt";
            this.add_name_txt.Size = new System.Drawing.Size(100, 20);
            this.add_name_txt.TabIndex = 0;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(0, -2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(359, 456);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // update_id_txt
            // 
            this.update_id_txt.Location = new System.Drawing.Point(398, 160);
            this.update_id_txt.Name = "update_id_txt";
            this.update_id_txt.Size = new System.Drawing.Size(100, 20);
            this.update_id_txt.TabIndex = 2;
            // 
            // update_name_txt
            // 
            this.update_name_txt.Location = new System.Drawing.Point(504, 160);
            this.update_name_txt.Name = "update_name_txt";
            this.update_name_txt.Size = new System.Drawing.Size(100, 20);
            this.update_name_txt.TabIndex = 3;
            // 
            // delete_id_txt
            // 
            this.delete_id_txt.Location = new System.Drawing.Point(398, 264);
            this.delete_id_txt.Name = "delete_id_txt";
            this.delete_id_txt.Size = new System.Drawing.Size(100, 20);
            this.delete_id_txt.TabIndex = 4;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(527, 64);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 5;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(622, 157);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 6;
            this.button2.Text = "Update";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(504, 264);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 7;
            this.button3.Text = "Delete";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // add
            // 
            this.add.AutoSize = true;
            this.add.Location = new System.Drawing.Point(395, 30);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(84, 13);
            this.add.TabIndex = 8;
            this.add.Text = "Add Department";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(395, 228);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Delete Department";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(395, 120);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Update Department";
            // 
            // CRUDForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.add);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.delete_id_txt);
            this.Controls.Add(this.update_name_txt);
            this.Controls.Add(this.update_id_txt);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.add_name_txt);
            this.Name = "CRUDForm";
            this.Text = "CRUDForm";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox add_name_txt;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox update_id_txt;
        private System.Windows.Forms.TextBox update_name_txt;
        private System.Windows.Forms.TextBox delete_id_txt;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label add;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}