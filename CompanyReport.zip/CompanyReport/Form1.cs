﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CompanyReport
{
    public partial class Form1 : Form
    {

        CompanyDBEntities DBObject = new CompanyDBEntities();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            show_data();
        }

        private void show_data()
        {
            dataGridView1.DataSource = DBObject.Departments.ToList();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void add_department_button_Click(object sender, EventArgs e)
        {
            Department department = new Department();
            department.department_name = add_department_tb.Text;

            DBObject.Departments.Add(department);
            DBObject.SaveChanges();
            add_department_tb.Text = "";

            show_data();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            int department_id = Convert.ToInt32(update_id_txt.Text);
            Department department = DBObject.Departments.Find(department_id);

            department.department_name = update_name_txt.Text;
            update_id_txt.Text = "";
            update_name_txt.Text = "";
            DBObject.SaveChanges();

            show_data();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int department_id = Convert.ToInt32(update_id_txt.Text);
            Department department = DBObject.Departments.Find(department_id);

            DBObject.Departments.Remove(department);
            DBObject.SaveChanges();
            update_id_txt.Text = "";

            show_data();
        }

    }
}
